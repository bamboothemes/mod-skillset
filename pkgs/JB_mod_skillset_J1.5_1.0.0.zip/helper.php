<?php
/**
 * @copyright	Copyright (c) 2014 Joomla. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die;

/**
 * Joomla - mod_zen_skills Helper Class.
 *
 * @package		Joomla.Site
 * @subpakage	Joomla.mod_zen_skills
 */
class modmod_zen_skillsHelper {
	
}