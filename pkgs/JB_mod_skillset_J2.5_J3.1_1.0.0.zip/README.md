mod_skillset
============

A Joomla module that displays one of those animated skillset bars.
